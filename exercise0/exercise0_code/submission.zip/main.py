from pattern import Checker, Circle, Spectrum

if __name__ == '__main__':
    checker = Checker(250, 25)
    checker.draw()
    checker.show()

